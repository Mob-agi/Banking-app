/*
This is the driver class that creates objects for each class so as to test each of their individual methods
Here we interactively ask the user to enter both the amounts to debit and credit from various account objects
Thereafter we dispaly the remaining balances of each individual accounts.
We calculate interest by invoking calculateInterest() method
then we add interest to the savings account object
We  the create an array of account references to saving and checking acounts objects
After proccessing the account we then print the updated balance gotten through getBalance method from the base class
*/
#include <iostream>
#include <iomanip>
#include "Account.h" // Account class definition
#include "SavingsAccount.h" // SavingsAccount class definition
#include "CheckingAccount.h" // CheckingAccount class definition
using namespace std;
 
int main()
{
   //Here we create an Account object
   Account account1( 47.0 ); 
   //Here we create a SavingsAccount object
   SavingsAccount account2( 38.0, .03 ); 
   //Here we create a CheckingAccount object
   CheckingAccount account3( 76.0, 1.0 ); // create CheckingAccount object
 
   cout << fixed << setprecision( 2 );
 
   // display initial balance of each object
   cout << "The balance in Account1 is : $" << account1.getBalance() << endl;
   cout << "The balance in account2 is : $" << account2.getBalance() << endl;
   cout << "The balance in Account3 is: $" << account3.getBalance() << endl;
 
    //Variables to hold user input
   double val1,val2,val3;
   // try to debit user inputted amount from account1
   cout << "\nPlease enter the amount you want to debit from Account 1." << endl;
   cin>>val1;
   account1.debit(val1);
   // try to debit user inputted amount from account2
   cout << "\nPlease enter the amount you want to debit from Account 2." << endl;
   cin>>val2;
   account2.debit(val2); 
   // try to debit user inputted amount from account3
   cout << "\nPlease enter the amount you want to debit from Account 3." << endl;
   cin>>val3;
   account3.debit(val3); 

   // Here we display balances after the user has done debiting
   cout << "\nThe Balance for Account 1 after debiting $ "<<val1<<" is: $" << account1.getBalance() << endl;
   cout << "The Balance for Account 1 after debiting $ "<<val2<<" is: $" << account2.getBalance() << endl;
   cout << "The Balance for Account 1 after debiting $ "<<val3<<" is: $" << account3.getBalance() << endl;
 
   //Variables to hold user input
   double val4,val5,val6;
   // try to credit user inputted amount from account1
   cout << "\nPlease enter the amount you want to credit to Account 1." << endl;
   cin>>val4;
   account1.credit(val4);
   // try to credit user inputted amount from account2
   cout << "\nPlease enter the amount you want to credit to Account 2." << endl;
   cin>>val5;
   account2.credit(val5);
   // try to credit user inputted amount from account3
   cout << "\nPlease enter the amount you want to credit to Account 3." << endl;
   cin>>val6;
   account3.credit(val6);

 
   // display balances
    // Here we display balances after the user has done debiting
   cout << "\nThe Balance for Account 1 after crediting $ "<<val4<<" is: $" << account1.getBalance() << endl;
   cout << "The Balance for Account 2 after creditingg $ "<<val5<<" is: $" << account2.getBalance() << endl;
   cout << "The Balance for Account 2 after crediting $ "<<val6<<" is: $" << account3.getBalance() << endl;
 
 
   // Prompt the user to add interest to SavingsAccount object account2
   double interestEarned = account2.calculateInterest();
   double val7;
   cout << "\nPlease enter the the interest for SavingsAccount2" << endl;
   cin>>val7;
   cout << "\nAdding $" << val7 << " interest to account2."
      << endl;
   account2.credit( val7 );
 
   cout << "\nThe new account2 balance: $" << account2.getBalance() << endl;
} 
