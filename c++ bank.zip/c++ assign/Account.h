/*
This is the constructor class from which teh savings and checking classes inherits from
It contains getters and setters for crediting, debiting and checking of initail balance by customers
*/
#ifndef ACCOUNT_H
#define ACCOUNT_H
 
class Account
{
public:
	// constructor initializes balance
   Account( double ); 
   // Here we do the addition of some amount to the account balance
   void credit( double ); 
   // Here we do the deducting some amount from the account balance
   bool debit( double ); 
   // Here we do the seting the account balance
   void setBalance( double ); 
   // Here we do the returning the account balance
   double getBalance(); 
private:
   double balance; // data member that stores the balance
}; 
 
#endif
