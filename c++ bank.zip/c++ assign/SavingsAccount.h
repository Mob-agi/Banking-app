/*

This account inherits from the Account class
It contains methods such as balance checking, calculation interest that a customer earns
*/
#ifndef SAVINGS_H
#define SAVINGS_H
 
 //Here we do the Account class definition
#include "Account.h" n
 
class SavingsAccount : public Account
{
public:
   // constructor initializes balance and interest rate
   SavingsAccount( double, double );
 
   //Here we determine interest owed
   double calculateInterest(); 
private:
	//Here we determine the interest rate (percentage) earned by account
   double interestRate; 
}; // end class SavingsAccount
 
#endif
