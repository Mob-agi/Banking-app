/*

This account inherits from the Account class
It contains methods such as balance checking, crediting and debiting into the check account by a customer
*/
#ifndef CHECKING_H
#define CHECKING_H
 
#include "Account.h"
 
class CheckingAccount : public Account
{
public:
   //Here the constructor initializes balance and transaction fee
   CheckingAccount( double, double );
 
   void credit( double ); 
   bool debit( double );
private:
	// Here we declare a variable tha will hold fee charged per transaction
   double transactionFee; 
 
   // utility function to charge fee
   void chargeFee();
}; 
 
#endif
